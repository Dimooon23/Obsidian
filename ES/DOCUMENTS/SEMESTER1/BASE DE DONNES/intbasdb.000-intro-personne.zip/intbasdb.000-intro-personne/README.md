# INT_BAS_DB - Langage SQL - Activité 000 - introduction (Élements de solution)

Projet contenant les élements de solution pour l'activité [INT_BAS_DB - Langage SQL - Activité 000 - introduction](https://mylos.cifom.ch/dhu/cours/intbasdb/langage-sql/activites/sql-activite-000-introduction.html), introduction au langage SQL sur le schéma personne.

* Le [script sql](./scripts/010-elements-solution.sql) contient les requêtes sql demandées.
* Le [journal d'exécution](./scripts/010-elements-solution.log) contient le retour du script dans la console.


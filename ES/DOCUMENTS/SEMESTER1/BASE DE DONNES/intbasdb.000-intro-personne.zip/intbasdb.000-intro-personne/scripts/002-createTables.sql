﻿/*
    Campanule - Script de création du schéma
    
    dominique huguenin (dominique.huguenin AT rpn.ch)
*/
-- Création de tables
CREATE TABLE IF NOT EXISTS personnes (
    numero INTEGER,
    nom VARCHAR(20),
    prenom VARCHAR(20),
    ville VARCHAR(30),
    code_postal VARCHAR(20),
    province VARCHAR(20),
    telephone VARCHAR(20),
    date_naissance DATE,
    sexe CHAR,
    assurance_sociale VARCHAR(20),
    couleur_yeux VARCHAR(20),
    langue VARCHAR(20),
   
    CONSTRAINT pk_personnes
        PRIMARY KEY (numero)   
);


--
-- introduction au langage SQL sur le schéma personne
-- script sql de solution
--
-- auteur : Dominique Huguenin (dominique.huguenin AT rpn.ch)
--

-- 1.
-- Ajouter un tuple qui contiendra les informations fictives vous concernant.

INSERT INTO personnes (
	    numero, nom,        prenom,     ville,    code_postal, province, 
	    telephone, date_naissance, sexe, assurance_sociale, couleur_yeux, langue    )
VALUES (1000,  'Huguenin', 'Dominque', 'La Baie', 'G7B 3H7',   'QUEBEC', 
        NULL,      NULL,           'H',  NULL,              'BRUN',       'FRANÇAIS') 
;

SELECT *
FROM personnes
WHERE numero = 1000
;

-- Modifier votre numéro de téléphone.

UPDATE personnes 
SET telephone = '(418) 345-2134' 
WHERE numero = 1000
;

SELECT *
FROM personnes
WHERE numero = 1000 AND telephone = '(418) 345-2134' 
;

-- Supprimer le tuple vous concernant. 
SELECT *
FROM personnes
WHERE numero = 1000
;

DELETE FROM personnes 
WHERE numero = 1000
;

SELECT *
FROM personnes
WHERE numero = 1000
;

-- 2.
-- De nombreuses erreurs sont survenues lors de la saisie de ces données. 
-- La ville de MONTREAL se trouve dans la province de QUEBEC. Modifier tous les tuples dans lesquels on retrouve cette erreur.

SELECT *
FROM personnes
WHERE ville = 'MONTREAL' AND Province <> 'QUEBEC'
;

UPDATE personnes 
SET Province = 'QUEBEC'
WHERE ville = 'MONTREAL' AND province <> 'QUEBEC'
;

SELECT *
FROM personnes
WHERE ville = 'MONTREAL' AND province <> 'QUEBEC'
;
-- 3.
-- Supprimer les tuples concernant les personnes nées avant le 31.12.1950.

SELECT nom, date_naissance, TO_CHAR(date_naissance,'DD.MM.YYYY') as date_naissance2 
FROM personnes 
WHERE date_naissance < TO_DATE('31.12.1950','DD.MM.YYYY')
;

DELETE FROM personnes 
WHERE date_naissance < TO_DATE('31.12.1950','DD.MM.YYYY')
;

SELECT nom, date_naissance, TO_CHAR(date_naissance,'DD.MM.YYYY') as date_naissance2 
FROM personnes 
WHERE date_naissance < TO_DATE('31.12.1950','DD.MM.YYYY')
;

-- 4.
-- Afficher la liste des langues parlées par le personnel de l'entreprise. 
-- (Chaque langue doit apparaître une seule fois).

SELECT DISTINCT langue 
FROM personnes ;

-- 5.
-- Afficher la liste des personnes (nom, prénom et numéro d'assurance sociale) dont le numéro d'assurance sociale 
-- comporte la suite de chiffre 432 dans l'un ou l'autre des trois groupes de chiffres.
-- Le numéro d’assurance sociale a le format suivant : « 999-999-999 ».

SELECT nom, assurance_sociale 
FROM personnes
WHERE assurance_sociale LIKE '%432%'
;

--ou avec une expression rationnelle (regex)

SELECT nom, assurance_sociale 
FROM personnes
WHERE assurance_sociale ~ '432'
;


-- 6.
-- Afficher la liste des personnes habitant la province de Québec, ayant les yeux BLEU et 
-- parlant FRANCAIS ou bien, ayant les yeux BRUN et parlant ANGLAIS. (Nom, couleur des yeux, langue et province)

-- A ET (( B ET C) OU (D ET E))
-- A *  (( B *  C) +  (D *  E))

SELECT nom, couleur_yeux, langue
FROM personnes
WHERE province = 'QUEBEC' AND ( 
        (langue = 'FRANCAIS' AND couleur_yeux = 'BLEU') OR 
        (Langue = 'ANGLAIS'  AND couleur_yeux = 'BRUN') 
        )
;


--ou
-- A ET (  B ET C  OU  D ET E )
-- A *  (  B *  C  +   D *  E )

SELECT nom, couleur_yeux, langue
FROM personnes
WHERE province = 'QUEBEC' AND ( 
        langue = 'FRANCAIS' AND couleur_yeux = 'BLEU' OR 
        Langue = 'ANGLAIS'  AND couleur_yeux = 'BRUN' 
        )
;


--ou
-- A ET B ET C OU A ET D ET E
-- A *  B *  C +  A *  D *  E

SELECT nom, couleur_yeux, langue
FROM personnes
WHERE province = 'QUEBEC' AND langue = 'FRANCAIS' AND couleur_yeux = 'BLEU' OR 
      province = 'QUEBEC' AND Langue = 'ANGLAIS'  AND couleur_yeux = 'BRUN'
;


-- 7.
-- Afficher la liste des personnes (nom, prénom) dont le prénom commence par S.

SELECT nom, prenom
FROM personnes
WHERE prenom LIKE 'S%' 
;

-- 8.
-- Afficher la liste des personnes (nom, prénom) par ordre alphabétique croissant des noms et des prénoms.

SELECT nom, prenom
FROM personnes
ORDER BY nom, prenom
;

-- 9.
-- Afficher la liste des personnes (nom, prénom) parlant ESPAGNOL.

SELECT nom, prenom
FROM personnes
WHERE langue = 'ESPAGNOL'
;

-- 10.
-- Afficher les noms, prénoms et dates de naissance des personnes aux yeux BLEU ou VERT et qui habitent la province de QUEBEC.

SELECT nom, prenom, date_naissance
FROM personnes
WHERE province = 'QUEBEC'
   AND couleur_yeux IN ('BLEU', 'VERT')
;

-- 11.
-- Afficher les noms, prénoms, codes postal et villes des personnes dont le code postal commence par G et qui a le chiffre 1 en 5ème position.
-- Exemple : G7B 1G4

SELECT nom, prenom, code_postal
FROM personnes
WHERE code_postal LIKE 'G___1%'
;

-- 12.
-- Créer la table *professions* et modifier la structure de la table *personnes* selon 
-- le modèle ci-dessous sans déclarer les contraintes de clé primaire et étrangère.

CREATE TABLE IF NOT EXISTS professions (
    code           INTEGER,
	libelle        VARCHAR(40),
	salaire_horaire NUMERIC(9,2))
;

ALTER TABLE personnes 
ADD COLUMN IF NOT EXISTS professions_code INTEGER
;

-- 13.
-- Saisir les données suivantes dans la table Professions.

DELETE FROM professions
;

INSERT INTO professions (code, libelle,salaire_horaire)
VALUES (100, 'Ingenieur', 110),
       (110, 'Technicien', 25),
       (120, 'Informaticien', 80),
       (130, 'Cuisinier', 110),
       (140, 'Secretaire', 50),
       (150, 'Telephoniste', 90),
       (160, 'Caissier', 90),
       (170, 'Manager', 150)
;

-- 14.
-- Mettre à jour les données de la table personnes Selon les règles suivantes :

UPDATE personnes 
SET professions_code = 100 
WHERE Ville = 'BAIE-COMEAU'
;

UPDATE personnes 
SET professions_code = 110 
WHERE Ville = 'GASPE' 
;

UPDATE personnes 
SET professions_code = 120 
WHERE Ville = 'LA MALBAIE' 
;

UPDATE personnes 
SET professions_code = 130 
WHERE Ville = 'MONTREAL' 
;

UPDATE personnes 
SET professions_code = 140 
WHERE Ville = 'OTTAWA' 
;

UPDATE personnes 
SET professions_code = 150 
WHERE Ville = 'QUEBEC' 
;

UPDATE personnes 
SET professions_code = 160 
WHERE Ville = 'RIVIERE-DU-LOUP'
;

UPDATE personnes 
SET professions_code = 170 
WHERE Ville = 'SEPT-ILES' 
;

-- 15.
-- Afficher pour chaque personne le nom de sa profession.

SELECT p.nom, p.prenom, pr.libelle
FROM Personnes p INNER JOIN professions pr
  ON p.professions_code = pr.code 
;

SELECT p.nom, p.prenom, pr.libelle
FROM Personnes p LEFT OUTER JOIN professions pr
  ON p.professions_code = pr.code 
;

-- 16.
-- Liste des personnes dont le salaire horaire est inférieur à Sfr 90.00 ne 
-- parlant ni le français, ni l'espagnol. (Nom, salaire horaire, langue parlée).

SELECT nom, salaire_horaire, langue
FROM personnes p INNER JOIN professions pr
  ON p.professions_code = pr.code
WHERE pr.salaire_horaire < 90
  AND p.langue NOT IN ('FRANCAIS', 'ESPAGNOL')
;
  

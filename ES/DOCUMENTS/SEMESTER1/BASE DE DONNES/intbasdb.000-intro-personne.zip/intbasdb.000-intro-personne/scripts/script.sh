#!/bin/bash
# 
# auteur: Dominique Huguenin (dominique.huguenin AT rpn.ch)
HOST=db.lxd
PORT=5432
USER=personne
PASSWORD=personnepass
DATABASE=personneDB
PSQL_SCRIPT=script.psql

PGPASSWORD=$PASSWORD psql -h $HOST -p $PORT -U $USER $DATABASE -f $PSQL_SCRIPT

﻿/*
    Campanule - Script de suppression du schéma
    
    dominique huguenin (dominique.huguenin AT rpn.ch)
*/

DROP TABLE IF EXISTS personnes
;

DROP TABLE IF EXISTS professions
;


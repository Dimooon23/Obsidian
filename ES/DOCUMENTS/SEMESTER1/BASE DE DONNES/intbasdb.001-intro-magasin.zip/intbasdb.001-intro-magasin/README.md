# INT_BAS_DB - Langage SQL - Activité 001 - introduction (Élements de solution)

Projet contenant les élements de solution pour l'activité [INT_BAS_DB - Langage SQL - Activité 001 - introduction](https://mylos.cifom.ch/cours/int-bas-db/langage-sql-activites/sql-activite-001-introduction/), introduction au langage SQL sur le schéma magasin.

* Le [script sql](./scripts/010-elements-solution.sql) contient les requêtes sql demandées.
* Le [journal d'exécution](./scripts/010-elements-solution.log) contient le retour du script dans la console.

# INT_BAS_DB - Langage SQL - Activité 002 - Expression et fonctions (Élements de solution)

Projet contenant les élements de solution pour l'activité  [INT_BAS_DB - Langage SQL - Activité 002 - Expression et fonctions](https://mylos.cifom.ch/dhu/cours/intbasdb/langage-sql/activites/sql-activite-002-expression-fonction.html), Utilisation des expressions et fonctions du langage SQL sur le schéma magasin

* Le [script sql](./scripts/010-002-elements-solution.sql) contient les requêtes sql demandées.
* Le [journal d'exécution](./scripts/010-elements-solution.log) contient le retour du script dans la console.

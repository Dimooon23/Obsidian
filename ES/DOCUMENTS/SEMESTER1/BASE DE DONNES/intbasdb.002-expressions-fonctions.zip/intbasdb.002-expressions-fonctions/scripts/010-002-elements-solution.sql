--
-- Utilisation des expressions et fonctions du langage SQL sur le schéma magasin
-- script sql de solution
--
-- auteur : Dominique Huguenin (dominique.huguenin AT rpn.ch)
--

--1.
--Afficher pour chaque article, la marge bénéficiaire prévue 
--(nom, prix d’achat, prix de vente, marge bénéficiaire).
SELECT a.nom, a.prix_vente - a.prix_achat as "marges bénéficiaire"
FROM articles a
;

--2.	
--Afficher pour chaque détail de commande (ligne de commande) le nom de l’article commandé, 
--la quantité, le prix de vente et la valeur totale du détail.
SELECT a.nom, lc.qte_commandee, lc.prix_vente_reel, 
       lc.qte_commandee * lc.prix_vente_reel as "total du détail"
FROM articles a 
  INNER JOIN lignes_commandes lc
     ON a.uuid = lc.articles_uuid
;

--3.	
--Ajouter une nouvelle commande pour le client JONAS Henri 
--(n° DEMO0000-0000-0000-0002-000000000014)
--*numéro de commande : DEMO0000-0000-0000-0003-000000000020
--*numéro de magasin : DEMO0000-0000-0000-0005-000000000010
--*date de la commande = date du jour (Utiliser la fonction adéquate)

INSERT INTO commandes 
        (uuid, date_commande, clients_uuid, magasins_uuid)
VALUES ('DEMO0000-0000-0000-0003-000000000020', CURRENT_DATE, 
        'DEMO0000-0000-0000-0002-000000000014', 'DEMO0000-0000-0000-0005-000000000010')
;

--4.	
--Afficher la liste des clients prénommés 'JEAN'. Vous ne savez pas comment 
--il a été orthographié, 
--il peut être en minuscules, en majuscules ou un mélange des deux...
--Afficher également leur nom.
SELECT nom, prenom
FROM clients
WHERE UPPER (prenom) = UPPER('JEAN')
;

--5.	
--Afficher le nombre total d’articles de notre stock.
SELECT SUM(qte_stock)
FROM articles
;

--6.	
--Afficher le prix d’achat moyen des articles.
SELECT AVG(prix_achat) 
FROM articles
;

--7	
--Afficher la valeur totale de l'ensemble des commandes effectuées dans 
--le magasin numéro DEMO0000-0000-0000-0005-000000000011.
SELECT SUM(lc.qte_commandee * lc.prix_vente_reel)
FROM lignes_commandes lc 
  INNER JOIN commandes c
     ON lc.commandes_uuid = c.uuid
  INNER JOIN magasins m
     ON c.magasins_uuid = m.uuid
WHERE m.uuid = 'DEMO0000-0000-0000-0005-000000000011'
;

--8.	
--Afficher la date de la dernière livraison effectuée (la plus récente)
SELECT MAX(date_livraison)
FROM livraisons
;

--9.	
--Liste des articles qui proviennent du fournisseur ELECTROLAMP avec 
--leur prix de vente et leur couleur.
SELECT a.nom, a.prix_vente, a.couleur
FROM articles a 
  INNER JOIN fournisseurs f
     ON a.fournisseurs_uuid = f.uuid
WHERE f.nom = 'ELECTROLAMP'
;

--10.
--Afficher les noms des localités des magasins dans lesquels le client DEFRERE 
--a commandé des articles.
SELECT DISTINCT m.Localite
FROM magasins m 
  INNER JOIN commandes c
     ON m.uuid = c.magasins_uuid
  INNER JOIN clients cl
     ON c.clients_uuid = cl.uuid
WHERE cl.nom = 'DEFRERE'
;

--11.
--Afficher la liste des articles commandés à plus d’un exemplaire par commande.
SELECT a.uuid, a.nom, lc.qte_commandee
FROM articles a
  INNER JOIN lignes_commandes lc
     ON a.uuid = lc.articles_uuid
WHERE lc.qte_commandee > 1
;

--12.
--Afficher la liste des magasins dans lesquels des commandes ont été passées 
--par des clients parisiens.
SELECT DISTINCT m.uuid, m.gerant, m.nom
FROM magasins m
  INNER JOIN commandes c
     ON m.uuid = c.magasins_uuid
  INNER JOIN clients cl
     ON c.clients_uuid = cl.uuid
WHERE cl.localite LIKE '%PARIS%'
;

--13	
--Afficher la liste des clients ayant commandé des produits provenant du 
--fournisseur LES STYLOS REUNIS.
SELECT DISTINCT cl.nom, cl.prenom
FROM clients cl
  INNER JOIN commandes c
     ON cl.uuid = c.clients_uuid
  INNER JOIN lignes_commandes lc
     ON c.uuid = lc.commandes_uuid
  INNER JOIN articles a
     ON lc.articles_uuid = a.uuid
  INNER JOIN fournisseurs f
     ON a.fournisseurs_uuid = f.uuid
WHERE f.nom = 'LES STYLOS REUNIS'
;

--14.
--Afficher la liste des détails de commande de plus de 200 francs avec 
--le nom du gérant du magasin, 
--le nom du client et le nom de l’article commandé et sa valeur totale.
SELECT cl.nom, a.nom, lc.qte_commandee * lc.prix_vente_reel, m.nom
FROM clients cl
  INNER JOIN commandes c
     ON cl.uuid = c.clients_uuid
  INNER JOIN magasins m
     ON m.uuid = c.magasins_uuid
  INNER JOIN lignes_commandes lc
     ON c.uuid = lc.commandes_uuid
  INNER JOIN articles a
     ON lc.articles_uuid = a.uuid
WHERE lc.qte_commandee * lc.prix_vente_reel > 200
;

--15.
--Afficher le nom des articles commandés par DEFRERE Marc.
SELECT DISTINCT a.uuid, a.nom
FROM clients cl
   INNER JOIN commandes c
      ON cl.uuid = c.clients_uuid
   INNER JOIN lignes_commandes lc
      ON c.uuid = lc.commandes_uuid
   INNER JOIN articles a
      On lc.articles_uuid = a.uuid
WHERE cl.nom = 'DEFRERE' 
  AND cl.prenom = 'Marc'
;


--16.
--Afficher le nombre de livraisons qui ont eu lieu au mois de juin de l'année en cours.
SELECT COUNT (*)
FROM livraisons
WHERE EXTRACT (MONTH FROM date_livraison) = 6
  AND EXTRACT (YEAR FROM date_livraison) = EXTRACT (YEAR FROM CURRENT_DATE)
;

SELECT COUNT (*)
FROM livraisons
WHERE EXTRACT (MONTH FROM date_livraison) = 6
  AND EXTRACT (YEAR FROM date_livraison) = 2005
;

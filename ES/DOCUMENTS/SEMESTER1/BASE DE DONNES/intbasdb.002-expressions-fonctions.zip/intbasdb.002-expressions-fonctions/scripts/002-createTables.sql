﻿/*
    Campanule - Script de création du schéma
    
    dominique huguenin (dominique.huguenin AT rpn.ch)
*/
-- Création de tables
CREATE TABLE IF NOT EXISTS magasins (
    uuid TEXT, -- aid
    localite TEXT NOT NULL,
    gerant TEXT,

    -- verrou optimiste
    version INTEGER DEFAULT 0,
    -- champs d'audit
    date_creation TIMESTAMP DEFAULT now(),
    user_creation TEXT,
    date_modification TIMESTAMP,
    user_modification TEXT,
    date_suppression  TIMESTAMP,
    user_suppression  TEXT,

    CONSTRAINT pk_magasins
        PRIMARY KEY (uuid)
)
;

CREATE TABLE IF NOT EXISTS fournisseurs (
    uuid TEXT, -- aid
    nom TEXT NOT NULL,

    -- verrou optimiste
    version INTEGER DEFAULT 0,
    -- champs d'audit
    date_creation TIMESTAMP DEFAULT now(),
    user_creation TEXT,
    date_modification TIMESTAMP,
    user_modification TEXT,
    date_suppression  TIMESTAMP,
    user_suppression  TEXT,

    CONSTRAINT pk_fornisseurs
        PRIMARY KEY (uuid)
)
;

CREATE TABLE IF NOT EXISTS clients (
    uuid TEXT, -- aid
    nom TEXT NOT NULL,
    prenom TEXT,
    code_pays VARCHAR(2),
    localite TEXT,
    chiffre_affaire NUMERIC(12,2),
    type_client TEXT,

    -- verrou optimiste
    version INTEGER DEFAULT 0,
    -- champs d'audit
    date_creation TIMESTAMP DEFAULT now(),
    user_creation TEXT,
    date_modification TIMESTAMP,
    user_modification TEXT,
    date_suppression  TIMESTAMP,
    user_suppression  TEXT,

    CONSTRAINT pk_clients
        PRIMARY KEY (uuid) 
)
;

CREATE TABLE IF NOT EXISTS articles (
    uuid TEXT, -- aid
    fournisseurs_uuid TEXT NOT NULL,
    nom TEXT NOT NULL,
    poids NUMERIC(12,2),
    couleur TEXT,
    qte_stock INTEGER,
    prix_achat NUMERIC(12,2),
    prix_vente NUMERIC(12,2),

    -- verrou optimiste
    version INTEGER DEFAULT 0,
    -- champs d'audit
    date_creation TIMESTAMP DEFAULT now(),
    user_creation TEXT,
    date_modification TIMESTAMP,
    user_modification TEXT,
    date_suppression  TIMESTAMP,
    user_suppression  TEXT,

    CONSTRAINT pk_articles
        PRIMARY KEY (uuid)
)
;

CREATE TABLE IF NOT EXISTS assemblages (
    articles_fini_uuid TEXT, -- aid
    articles_composant_uuid TEXT, -- aid
    qte_composant INTEGER NOT NULL,

    CONSTRAINT pk_assemblages
        PRIMARY KEY (articles_fini_uuid,articles_composant_uuid)
)
;

CREATE TABLE IF NOT EXISTS commandes (
    uuid TEXT, -- aid
    clients_uuid TEXT NOT NULL,
    magasins_uuid TEXT NOT NULL,
    date_commande     TIMESTAMP NOT NULL,

    -- verrou optimiste
    version INTEGER DEFAULT 0,
    -- champs d'audit
    date_creation TIMESTAMP DEFAULT now(),
    user_creation TEXT,
    date_modification TIMESTAMP,
    user_modification TEXT,
    date_suppression  TIMESTAMP,
    user_suppression  TEXT,

    CONSTRAINT pk_commandes
        PRIMARY KEY (uuid)
)
;

CREATE TABLE IF NOT EXISTS lignes_commandes (
    commandes_uuid TEXT,
    articles_uuid TEXT,
    qte_commandee INTEGER NOT NULL,
    qte_totale_livree  INTEGER,
    prix_vente_reel NUMERIC(12,2),
    date_livraison_prevue TIMESTAMP,
    
    CONSTRAINT pk_lignes_commandes
        PRIMARY KEY (commandes_uuid, articles_uuid)
)
;

CREATE TABLE IF NOT EXISTS livraisons (
    uuid TEXT, -- aid
    clients_uuid TEXT NOT NULL,
    magasins_uuid TEXT NOT NULL,
    date_livraison     TIMESTAMP NOT NULL,

    -- verrou optimiste
    version INTEGER DEFAULT 0,
    -- champs d'audit
    date_creation TIMESTAMP DEFAULT now(),
    user_creation TEXT,
    date_modification TIMESTAMP,
    user_modification TEXT,
    date_suppression  TIMESTAMP,
    user_suppression  TEXT,

    CONSTRAINT pk_livraisons
        PRIMARY KEY (uuid)
)
;

CREATE TABLE IF NOT EXISTS lignes_livraisons (
    livraisons_uuid TEXT NOT NULL, --aid
    articles_livre_uuid TEXT NOT NULL, --aid

    lignes_commandes_commandes_uuid TEXT NOT NULL,
    lignes_commandes_articles_uuid TEXT NOT NULL,

    qte_livree  INTEGER NOT NULL,
    
    CONSTRAINT pk_lignes_livraisons
        PRIMARY KEY (livraisons_uuid, articles_livre_uuid)
)
;


-- Ajout des contraintes supplémentaire
ALTER TABLE IF EXISTS articles
    DROP CONSTRAINT IF EXISTS fk1_articles_fournisseurs,
    ADD CONSTRAINT fk1_articles_fournisseurs
            FOREIGN KEY (fournisseurs_uuid)
            REFERENCES fournisseurs (uuid)
;

ALTER TABLE IF EXISTS assemblages
    DROP CONSTRAINT IF EXISTS fk1_assemblasges_articles_fini,
    ADD CONSTRAINT fk1_assemblasges_articles_fini
            FOREIGN KEY (articles_fini_uuid)
            REFERENCES articles (uuid),
    DROP CONSTRAINT IF EXISTS fk2_assemblasges_articles_composant,
    ADD CONSTRAINT fk2_assemblasges_articles_composant
            FOREIGN KEY (articles_composant_uuid)
            REFERENCES articles (uuid)
;


ALTER TABLE IF EXISTS commandes
    DROP CONSTRAINT IF EXISTS fk1_commandes_clients,
    ADD CONSTRAINT fk1_commandes_clients
            FOREIGN KEY (clients_uuid)
            REFERENCES clients (uuid),
    DROP CONSTRAINT IF EXISTS fk2_livraisons_magasins,
    ADD CONSTRAINT fk2_livraisons_magasins
            FOREIGN KEY (magasins_uuid)
            REFERENCES magasins (uuid)
;

ALTER TABLE IF EXISTS lignes_commandes
    DROP CONSTRAINT IF EXISTS fk1_lignes_commandes_commandes ,
    ADD CONSTRAINT fk1_lignes_commandes_commandes
            FOREIGN KEY (commandes_uuid)
            REFERENCES commandes (uuid) ON DELETE CASCADE,
    DROP CONSTRAINT IF EXISTS fk2_lignes_commandes_articles ,
    ADD CONSTRAINT fk2_lignes_commandes_articles 
            FOREIGN KEY (articles_uuid)
            REFERENCES articles (uuid)
;

ALTER TABLE IF EXISTS livraisons
    DROP CONSTRAINT IF EXISTS fk1_livraisons_clients,
    ADD CONSTRAINT fk1_livraisons_clients
            FOREIGN KEY (clients_uuid)
            REFERENCES clients (uuid),
    DROP CONSTRAINT IF EXISTS fk2_livraisons_magasins,
    ADD CONSTRAINT fk2_livraisons_magasins
            FOREIGN KEY (magasins_uuid)
            REFERENCES magasins (uuid)
;

ALTER TABLE IF EXISTS lignes_livraisons
    DROP CONSTRAINT IF EXISTS fk1_lignes_livraisons_livraisons ,
    ADD CONSTRAINT fk1_lignes_livraisons_livraisons
            FOREIGN KEY (livraisons_uuid)
            REFERENCES livraisons (uuid) ON DELETE CASCADE,
    DROP CONSTRAINT IF EXISTS fk2_lignes_livraisons_articles_livre ,
    ADD CONSTRAINT fk2_lignes_livraisons_articles_livre 
            FOREIGN KEY (articles_livre_uuid)
            REFERENCES articles (uuid),
    DROP CONSTRAINT IF EXISTS fk3_lignes_livraisons_lignes_commandes ,
    ADD CONSTRAINT fk3_lignes_livraisons_lignes_commandes 
            FOREIGN KEY (lignes_commandes_commandes_uuid,lignes_commandes_articles_uuid)
            REFERENCES lignes_commandes (commandes_uuid, articles_uuid)


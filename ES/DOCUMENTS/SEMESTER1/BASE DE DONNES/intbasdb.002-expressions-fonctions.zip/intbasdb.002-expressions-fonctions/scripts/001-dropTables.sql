﻿/*
    Campanule - Script de suppression du schéma
    
    dominique huguenin (dominique.huguenin AT rpn.ch)
*/

DROP TABLE IF EXISTS lignes_livraisons
;

DROP TABLE IF EXISTS livraisons
;

DROP TABLE IF EXISTS lignes_commandes
;

DROP TABLE IF EXISTS commandes
;

DROP TABLE IF EXISTS assemblages
;

DROP TABLE IF EXISTS articles
;


DROP TABLE IF EXISTS clients
;

DROP TABLE IF EXISTS magasins
;

DROP TABLE IF EXISTS fournisseurs
;

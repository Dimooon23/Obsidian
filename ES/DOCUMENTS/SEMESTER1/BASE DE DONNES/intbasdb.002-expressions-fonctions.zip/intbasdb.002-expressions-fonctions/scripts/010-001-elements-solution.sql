--
-- introduction au langage SQL sur le schéma magasin
-- script sql de solution
--
-- auteur : Dominique Huguenin (dominique.huguenin AT rpn.ch)
--

-- 1. 
-- Sélectionnez tous les articles ROUGE dont le poids est supérieur à 100 g

SELECT nom, poids
FROM articles 
WHERE poids > 100 
    AND couleur = 'ROUGE'
;

-- 2. 
-- Listez tous les noms de clients commençant par DE.

SELECT nom
FROM clients
WHERE nom LIKE 'DE%'
;

-- 3. 
-- Listez les articles dont la couleur est ROUGE ou VERT.

SELECT uuid, nom, couleur
FROM articles
WHERE couleur IN ('ROUGE', 'VERT')
;

-- 4. 
-- Sélectionnez les articles dont le poids se situe entre 100 et 600g (bornes comprises) 
-- et affichez-les par ordre décroissant des poids.

SELECT uuid, nom, poids
FROM articles
WHERE poids BETWEEN 100 AND 600
ORDER BY poids DESC
;

-- 5. 
-- Listez les articles dont la couleur n'a pas été saisie.

SELECT nom, couleur
FROM articles
WHERE couleur IS NULL
;

-- 6. 
-- Affichez la liste des clients (nom, prénom, localité) Belges (B).

SELECT nom, prenom, localite
FROM clients
WHERE code_pays = 'B'
;

-- 7. 
-- Ajoutez le fournisseur « LES PAPIERS REUNIS » qui portera le uuid DEMO0000-0000-0000-0006-000000000006.

INSERT INTO Fournisseurs 
          (uuid,nom)
   VALUES ('DEMO0000-0000-0000-0006-000000000006', 'LES PAPIERS REUNIS')
;

-- 8. 
-- Ajoutez une colonne (nom) à la table MAGASINS pour stocker le nom des différents magasins. 
-- Cette colonne sera une chaîne de 50 caractères.

ALTER TABLE magasins 
ADD COLUMN IF NOT EXISTS nom VARCHAR (50)
;

-- 9. 
-- Complétez la table MAGASINS de la façon suivante : 

UPDATE magasins 
SET nom = 'LA PLUME CHIC' 
WHERE uuid = 'DEMO0000-0000-0000-0003-000000000001'
;

UPDATE magasins 
SET nom = 'LE CLASSEUR À 4 TROUS'
WHERE uuid = 'DEMO0000-0000-0000-0003-000000000002'
;

UPDATE magasins 
SET nom = 'LE PAPYRUS' 
WHERE uuid = 'DEMO0000-0000-0000-0003-000000000003'
;

UPDATE magasins 
SET nom = 'LA COMBINE'
WHERE uuid = 'DEMO0000-0000-0000-0003-000000000004'
;

UPDATE magasins 
SET nom = 'LE FOURRE-TOUT'
WHERE uuid = 'DEMO0000-0000-0000-0003-000000000005'
;

-- 10. 
-- Listez les articles dont la couleur n’est ni BLANC ni ROUGE.

SELECT nom, couleur
FROM articles
WHERE couleur NOT IN ('BLANC', 'ROUGE')
;

-- 11. 
-- Affichez la liste des clients ayant passé une commande entre le 8 et le 10 juin 2010
--  (nom, prénom, date de commande).

SELECT nom, prenom, date_commande
FROM clients INNER JOIN commandes
   ON  clients.uuid = commandes.clients_uuid
WHERE   
   date_commande BETWEEN '2010/06/08' AND '2010/06/10'
;
	    
SELECT nom, prenom, date_commande
FROM clients INNER JOIN commandes
   ON  clients.uuid = commandes.clients_uuid
WHERE   
   date_commande BETWEEN  TO_DATE ('08.06.2010','DD.MM.YYYY')
                          AND TO_DATE ('10.06.2010','DD.MM.YYYY')
;

-- 12. 
-- Affichez la liste des magasins de ROUEN pour lesquels le nom n’a pas été saisi
-- (numéro, localité, nom du gérant).

SELECT uuid, localite, gerant
FROM magasins
WHERE localite = 'ROUEN'
    AND nom IS NULL
;
	

-- 13.
-- Affichez la liste des noms de magasins depuis lesquels au moins 
-- une livraison a été effectuée (nom du magasin, localité et date de livraison).

SELECT nom, localite, date_livraison
FROM magasins INNER JOIN  livraisons
  ON  magasins.uuid = livraisons.magasins_uuid
;

-- 14. 
-- Listez tous les articles dont le nom ne comporte pas le mot CRAYON (numéro, nom).

SELECT uuid, nom
FROM articles
WHERE nom NOT LIKE '%CRAYON%'
;

-- 15. 
-- Ajoutez les articles suivants :

INSERT INTO articles 
    (uuid, fournisseurs_uuid, nom, poids, couleur, qte_stock, prix_achat, prix_vente)
VALUES
    (uuid_generate_v4()::TEXT, 'DEMO0000-0000-0000-0006-000000000002','GOMME', 5, 'ROSE', 300, 1, 2)
;
INSERT INTO articles 
    (uuid, fournisseurs_uuid, nom, poids, couleur, qte_stock, prix_achat, prix_vente)
VALUES 
    (uuid_generate_v4()::TEXT, 'DEMO0000-0000-0000-0006-000000000002','GOMME', 5, 'BLANCHE', 250, 1, 2)
;

INSERT INTO articles 
    (uuid, fournisseurs_uuid, nom, poids, couleur, qte_stock, prix_achat, prix_vente)
VALUES 
    (uuid_generate_v4()::TEXT, 'DEMO0000-0000-0000-0006-000000000004', 'CLASSEUR A4', 150, 'VERT', 20, 5, 7)
;

INSERT INTO articles 
    (uuid, fournisseurs_uuid, nom, poids, couleur, qte_stock, prix_achat, prix_vente)
VALUES 
    (uuid_generate_v4()::TEXT, 'DEMO0000-0000-0000-0006-000000000004','CLASSEUR A4', 150, 'NOIR', 20, 5, 7)
;

--16. 
-- Liste des articles commandés au moins une fois avec le nom du fournisseur 
-- de cet article (numéro et nom de l’article, nom du fournisseur)

SELECT DISTINCT a.uuid, a.nom, f.nom
FROM fournisseurs f 
  INNER JOIN articles a ON f.uuid = a.fournisseurs_uuid
  INNER JOIN lignes_commandes lc ON a.uuid = lc.articles_uuid
;

-- 17. 
-- Affichez le détail de la livraison "DEMO0000-0000-0000-0007-000000000003"
-- (date, nom du client concerné, nom des articles livrés avec leur quantité).

SELECT l.date_livraison, c.nom, a.nom, ll.qte_livree
FROM articles a
  INNER JOIN lignes_livraisons ll ON a.uuid = ll.articles_livre_uuid
  INNER JOIN livraisons l ON ll.livraisons_uuid = l.uuid
  INNER JOIN clients  c ON l.clients_uuid = c.uuid
WHERE l.uuid = 'DEMO0000-0000-0000-0007-000000000003'
;

